// creating all factories here in a separate file is needed to get tree-shaking working
import * as allFactories from '../factoriesAny.js'

export const all = allFactories
