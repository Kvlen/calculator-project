---
name: New issue
about: Create an issue to help us improve
title: ''
labels: ''
assignees: ''

---

The issues section is used only for bug reports. Please use the [Discussions](https://github.com/josdejong/mathjs/discussions) section to ask questions and share ideas and suggestions.

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior.
